<?php
header('Content-Type: application/json');

// Check if subject parameter is provided
if (!isset($_POST['subject'])) {
    echo json_encode(['success' => false, 'message' => 'Subject parameter is required']);
    exit;
}

$subject = $_POST['subject'];
$allowedSubjects = ['english', 'math', 'science', 'filipino'];

// Validate subject
if (!in_array($subject, $allowedSubjects)) {
    echo json_encode(['success' => false, 'message' => 'Invalid subject']);
    exit;
}

// Get the project root directory
$projectRoot = dirname(__DIR__);
$subjectRFIDDir = $projectRoot . '/subjectRFID';

// Define script paths
$vbsScript = $subjectRFIDDir . '/run' . ucfirst($subject) . 'RFID.vbs';
$batScript = $subjectRFIDDir . '/run' . ucfirst($subject) . 'RFID.bat';

// Check if scripts exist
if (!file_exists($vbsScript)) {
    echo json_encode(['success' => false, 'message' => 'VBS script not found for ' . $subject]);
    exit;
}

if (!file_exists($batScript)) {
    echo json_encode(['success' => false, 'message' => 'BAT script not found for ' . $subject]);
    exit;
}

try {
    // First, stop any existing RFID processes to avoid conflicts
    $stopScript = $projectRoot . '/stopRFID.vbs';
    if (file_exists($stopScript)) {
        exec('cscript //nologo "' . $stopScript . '"', $output, $returnCode);
    }
    
    // Wait a moment for processes to stop
    sleep(1);
    
    // Execute the VBS script (which will run the BAT script)
    $command = 'cscript //nologo "' . $vbsScript . '"';
    exec($command, $output, $returnCode);
    
    if ($returnCode === 0) {
        echo json_encode([
            'success' => true, 
            'message' => ucfirst($subject) . ' RFID system started successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to start ' . $subject . ' RFID system. Return code: ' . $returnCode
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Error starting ' . $subject . ' RFID system: ' . $e->getMessage()
    ]);
}
?>