<?php
/**
 * AJAX Email Verification Endpoint
 * Handles email verification without page redirects
 */

header('Content-Type: application/json');
require_once '../db/db_connect.php';
require_once 'email_verification.php';

// Check if token is provided
if (!isset($_GET['token']) || empty($_GET['token'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'No verification token provided.'
    ]);
    exit;
}

$token = trim($_GET['token']);

// Initialize email verification system
$emailVerification = new EmailVerification($conn);

// Verify the token
$result = $emailVerification->verifyEmailToken($token);

// Return JSON response
echo json_encode($result);
exit;
?>
