<?php
session_start();
header('Content-Type: application/json');

// Prevent caching
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'validate_display_session':
        // Validate display RFID session
        $valid = isset($_SESSION['selected_section_id']) && 
                 isset($_SESSION['selected_grade_level']) && 
                 isset($_SESSION['selected_section']);
        echo json_encode(['valid' => $valid]);
        break;
        
    case 'validate_attendance_session':
        // Validate attendance view session
        $valid = isset($_SESSION['selected_section_id']) && 
                 isset($_SESSION['selected_grade_level']) && 
                 isset($_SESSION['selected_section']);
        echo json_encode(['valid' => $valid]);
        break;
        
    default:
        echo json_encode(['valid' => false]);
        break;
}
?>





