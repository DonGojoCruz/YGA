<?php
/**
 * Direct Email Verification
 * Simple verification that shows result immediately without AJAX
 */

require_once '../db/db_connect.php';
require_once 'email_verification.php';

$page_title = "Email Verification";
$additional_css = "css/global.css";

// Check if token is provided
if (!isset($_GET['token']) || empty($_GET['token'])) {
    $error_message = "No verification token provided.";
    $show_error = true;
} else {
    $token = trim($_GET['token']);
    
    // Initialize email verification system
    $emailVerification = new EmailVerification($conn);
    
    // Verify the token
    $result = $emailVerification->verifyEmailToken($token);
    
    if ($result['status'] === 'success') {
        $success_message = $result['message'];
        $show_success = true;
    } else {
        $error_message = $result['message'];
        $show_error = true;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <title><?php echo $page_title; ?></title>
    <?php include '../includes/head.php'; ?>
    <link rel="stylesheet" href="../<?php echo $additional_css; ?>">
    <style>
        .verification-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 40px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .verification-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .success-icon {
            color: #4CAF50;
        }
        
        .error-icon {
            color: #f44336;
        }
        
        .verification-title {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
        }
        
        .verification-message {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
            margin-bottom: 30px;
        }
        
    </style>
</head>
<body>
    <div class="verification-container">
        <?php if (isset($show_success) && $show_success): ?>
            <div class="verification-icon success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1 class="verification-title">Email Verified Successfully!</h1>
            <p class="verification-message">
                <?php echo htmlspecialchars($success_message); ?>
            </p>
        <?php elseif (isset($show_error) && $show_error): ?>
            <div class="verification-icon error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h1 class="verification-title">Verification Failed</h1>
            <p class="verification-message">
                <?php echo htmlspecialchars($error_message); ?>
            </p>
        <?php endif; ?>
        
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>
</body>
</html>
