<?php
/**
 * Validate Time Out password against section password from database
 */

require_once '../db/db_connect.php';

// Set Manila timezone
date_default_timezone_set('Asia/Manila');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['password'])) {
        echo json_encode(['success' => false, 'message' => 'Password not provided']);
        exit;
    }
    
    $enteredPassword = trim($input['password']);
    
    // Get current target section from config file
    $config_file = "../rfid_config.txt";
    $TARGET_GRADE = '1';
    $TARGET_SECTION = 'Mango';
    
    if (file_exists($config_file)) {
        $config_lines = file($config_file, FILE_IGNORE_NEW_LINES);
        foreach ($config_lines as $line) {
            $line = trim($line);
            if (strpos($line, 'TARGET_GRADE=') === 0) {
                $TARGET_GRADE = trim(substr($line, 13));
            } elseif (strpos($line, 'TARGET_SECTION=') === 0) {
                $TARGET_SECTION = trim(substr($line, 15));
            }
        }
    }
    
    // Query the section table for the password
    $query = "SELECT password FROM section WHERE grade_level = ? AND section = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $TARGET_GRADE, $TARGET_SECTION);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $correctPassword = $row['password'];
        
        if ($enteredPassword === $correctPassword) {
            echo json_encode([
                'success' => true,
                'message' => 'Password verified successfully',
                'grade' => $TARGET_GRADE,
                'section' => $TARGET_SECTION
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Incorrect password',
                'grade' => $TARGET_GRADE,
                'section' => $TARGET_SECTION
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Section not found in database',
            'grade' => $TARGET_GRADE,
            'section' => $TARGET_SECTION
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Error validating timeout password: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>