<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../db/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_password = $_POST['password'] ?? '';
    
    // Check if user has selected a section
    if (!isset($_SESSION['selected_section_id'])) {
        echo json_encode(['success' => false, 'message' => 'No section selected']);
        exit;
    }
    
    $section_id = $_SESSION['selected_section_id'];
    
    // Get section password from database
    $stmt = $conn->prepare("SELECT password FROM section WHERE id = ?");
    $stmt->bind_param("i", $section_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $section = $result->fetch_assoc();
        $section_password = $section['password'];
        
        // Check if password matches
        if ($input_password === $section_password) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid password']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Section not found']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
