<?php
header('Content-Type: application/json');

include '../db/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get form data
$subjectId = intval($_POST['subject_id']);
$subjectName = trim($_POST['subject_name']);
$subjectCode = trim($_POST['subject_code']);
$subjectDescription = trim($_POST['subject_description']);
$gradeLevel = trim($_POST['grade_level']);
$sectionId = intval($_POST['section_id']);
$teacherId = !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null;

// Validate required fields
if (empty($subjectName)) {
    echo json_encode(['success' => false, 'message' => 'Subject name is required']);
    exit();
}

if (empty($gradeLevel)) {
    echo json_encode(['success' => false, 'message' => 'Grade level is required']);
    exit();
}

if (empty($sectionId)) {
    echo json_encode(['success' => false, 'message' => 'Section is required']);
    exit();
}

try {
    // Check if subject exists
    $checkSql = "SELECT id FROM subjects WHERE id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("i", $subjectId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Subject not found']);
        exit();
    }
    
    // Update subject
    $updateSql = "UPDATE subjects SET 
                  subject_name = ?, 
                  subject_code = ?, 
                  subject_description = ?, 
                  grade_level = ?, 
                  section_id = ?, 
                  teacher_id = ?,
                  updated_at = CURRENT_TIMESTAMP
                  WHERE id = ?";
    
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ssssiii", 
        $subjectName, 
        $subjectCode, 
        $subjectDescription, 
        $gradeLevel, 
        $sectionId, 
        $teacherId, 
        $subjectId
    );
    
    if ($updateStmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Subject updated successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update subject: ' . $conn->error
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} finally {
    if (isset($checkStmt)) $checkStmt->close();
    if (isset($updateStmt)) $updateStmt->close();
    $conn->close();
}
?>
