<?php
/**
 * Stop all RFID processes
 * This function stops any running RFID Python scripts
 */

try {
    // Try to stop RFID processes using the stop script
    $projectRoot = __DIR__ . '/..';
    $stopScript = $projectRoot . '/stopRFID.py';
    
    if (file_exists($stopScript)) {
        exec('python "' . $stopScript . '" 2>&1', $output, $returnCode);
        
        if ($returnCode === 0) {
            echo json_encode([
                'success' => true, 
                'message' => 'RFID processes stopped successfully'
            ]);
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'Failed to stop RFID processes',
                'error' => implode("\n", $output)
            ]);
        }
    } else {
        // Fallback: try to kill Python processes that might be running RFID scripts
        exec('taskkill /f /im python.exe 2>&1', $output, $returnCode);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Attempted to stop RFID processes'
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Error stopping RFID processes: ' . $e->getMessage()
    ]);
}
?>
