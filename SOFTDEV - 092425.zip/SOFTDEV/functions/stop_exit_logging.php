<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../db/db_connect.php';

// Debug logging
error_log("🛑 STOP EXIT LOGGING: Request received");
error_log("🛑 Session data: " . print_r($_SESSION, true));
error_log("🛑 Request method: " . $_SERVER['REQUEST_METHOD']);

// Check if user has selected a section
if (!isset($_SESSION['selected_section_id']) || !isset($_SESSION['selected_grade_level']) || !isset($_SESSION['selected_section'])) {
    error_log("❌ No section selected in session");
    echo json_encode(['success' => false, 'message' => 'No section selected']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $grade = $_SESSION['selected_grade_level'];
    $section = $_SESSION['selected_section'];
    
    error_log("🛑 Stopping exit logging for Grade: $grade, Section: $section");
    
    // Update config file to disable exit logging
    $config_file = __DIR__ . "/../rfid_config.txt";
    $config_content = "TARGET_GRADE={$grade}\nTARGET_SECTION={$section}\nTARGET_SUBJECT=\nEXIT_LOGGING=false\n";
    
    error_log("🛑 Writing to config file: $config_file");
    error_log("🛑 Config content: " . $config_content);
    
    if (file_put_contents($config_file, $config_content) !== false) {
        error_log("✅ Exit logging config written successfully");
        echo json_encode(['success' => true, 'message' => 'Exit logging stopped']);
    } else {
        error_log("❌ Failed to write config file");
        echo json_encode(['success' => false, 'message' => 'Failed to stop exit logging']);
    }
} else {
    error_log("❌ Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
