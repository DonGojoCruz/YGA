<?php
session_start();
require_once '../db/db_connect.php';
require_once 'email_verification.php';

$page_title = "Email Verification";
$additional_css = "css/global.css";

// Get token from URL
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
?>
<!doctype html>
<html lang="en">
<head>
    <title><?php echo $page_title; ?></title>
    <?php include '../includes/head.php'; ?>
    <link rel="stylesheet" href="../<?php echo $additional_css; ?>">
    <style>
        .verification-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 40px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .verification-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .success-icon {
            color: #4CAF50;
        }
        
        .error-icon {
            color: #f44336;
        }
        
        .loading-icon {
            color: #2196F3;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .verification-title {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
        }
        
        .verification-message {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
            margin-bottom: 30px;
        }
        
        .verification-actions {
            margin-top: 30px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 30px;
            margin: 10px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        
        .btn-primary {
            background: #4CAF50;
            color: white;
        }
        
        .btn-primary:hover {
            background: #45a049;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .back-link {
            margin-top: 20px;
            font-size: 14px;
        }
        
        .back-link a {
            color: #4CAF50;
            text-decoration: none;
        }
        
        .back-link a:hover {
            text-decoration: underline;
        }
        
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="verification-container">
        <!-- Loading State -->
        <div id="loadingState">
            <div class="verification-icon loading-icon">
                <i class="fas fa-spinner"></i>
            </div>
            <h1 class="verification-title">Verifying Email...</h1>
            <p class="verification-message">Please wait while we verify your email address.</p>
        </div>
        
        <!-- Success State -->
        <div id="successState" class="hidden">
            <div class="verification-icon success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1 class="verification-title">Email Verified Successfully!</h1>
            <p class="verification-message" id="successMessage">
                Your email has been successfully verified and your student registration is now complete!
            </p>
            <div class="verification-actions">
                <a href="index.php" class="btn btn-primary">Go to Login</a>
                <a href="manage.php" class="btn btn-secondary">View Students</a>
            </div>
        </div>
        
        <!-- Error State -->
        <div id="errorState" class="hidden">
            <div class="verification-icon error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h1 class="verification-title">Verification Failed</h1>
            <p class="verification-message" id="errorMessage">
                There was an error verifying your email address.
            </p>
            <div class="verification-actions">
                <a href="index.php" class="btn btn-primary">Go to Login</a>
                <a href="manage.php" class="btn btn-secondary">Back to Students</a>
            </div>
        </div>
        
        <div class="back-link">
            <a href="index.php">← Back to Home</a>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>
    <script>
        // Verify email on page load
        document.addEventListener('DOMContentLoaded', function() {
            const token = '<?php echo htmlspecialchars($token); ?>';
            
            if (!token) {
                showError('No verification token provided.');
                return;
            }
            
            // Verify email via AJAX
            fetch('verify_ajax.php?token=' + encodeURIComponent(token))
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        showSuccess(data.message);
                    } else {
                        showError(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showError('Network error occurred while verifying email.');
                });
        });
        
        function showSuccess(message) {
            document.getElementById('loadingState').classList.add('hidden');
            document.getElementById('successState').classList.remove('hidden');
            document.getElementById('successMessage').textContent = message;
        }
        
        function showError(message) {
            document.getElementById('loadingState').classList.add('hidden');
            document.getElementById('errorState').classList.remove('hidden');
            document.getElementById('errorMessage').textContent = message;
        }
    </script>
</body>
</html>
