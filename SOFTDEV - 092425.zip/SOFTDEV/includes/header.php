<header class="header" aria-label="Top navigation">
  <div class="brand">Young Generation Academy</div>
</header>